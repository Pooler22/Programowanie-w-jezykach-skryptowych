Instalacja:

pip install python-color-logger

pip install asciimatics


Run:

open: lab\database

py -3 Main.py

Zadania:

3. ~~Na bazie zadania 2 dodac do skryptu mozliwosc obslugi "bazy danych" w pliku.
Skrypt powinien obslugiwac:~~
   1. ~~Ladowanie "bazy danych" z pliku o okreslonej nazwie.~~
   2. ~~Zapisywanie "bazy danych" do pliku o okreslonej nazwie.~~
   3. ~~Dodawanie nowych wpisow do "bazy danych".~~
   4. ~~Usuwanie wpisow z "bazy danych".~~
   5. ~~Wyswietlanie zawartosci "bazy danych".~~
   6. ~~Wyswietlanie listy "opcji"~~

3_1. ~~Do zadania 3 wykorzystac plik tekstowy z danymi w nastepujacym formacie:
Imie(znak nie bedacy bialem znakiem lub litera)Nazwisko~~

4. ~~Wczytac liste zdalnie z pliku lista.txt.~~

4_1. ~~Prosze zapewnic mozliwosc rozroznienia w bazie nowych i starych rekordow (w celu uzupelnienia "pustych" pol) wczytywanych z pliku "nowego formatu".~~
~~Prosze zastosowac podmenu.~~

5. ~~Prosze stworzyc obiekt (klase abstrakcyjna) posiadajacy opcje:~~
   1. ~~Zapisywania listy do pliku~~
   2. ~~Wczytywania listy z pliku~~
   3. ~~Wyswietlania listy na ekranie~~
   4. ~~Z tego obiektu maja dziedziczyc dwa obiekty zapewniajace odpowiednio implementacje tych operacji dla list "z pliku na dysku" (zadanie 3) i z pliku "na stronie" (zadanie 4).~~
   5. ~~Losową ilość obiektów obu typów dodać do listy. Następnie iterując przez tą listę wywołać funkcję (np zapisu) BEZ sprawdzania typu obiektu!!!~~

5_1. ~~Przygotowac obiekt losowo generujacy liste obiektow z zadania 5 oraz drugi obiekt, ktory generuje losowe elementy(dwoch rodzajow) i dodaje do jednego z dwoch typow obiektow. Jeden z generatorow danych ma pobierac je z internetu.~~

6a ~~W skrypcie prosze pobrac imiona z URL (SA W KATALOGU PRZEDMIOTU)(URL skladacie sami :)), posortowac, wystwietlic posortowana liste i liczbe rekordow. To samo nalezy zrobic z lista nazwisk.
Imiona: imiona.txt
Nazwiska: nazwiska.txt~~

6b ~~Z danych pobranych w zadaniu 6a wygenerowac liste w postaci:
Numer, Imie, Naziwsko
Liste zapisac do pliku. Po "wykorzystaniu" wszystkich imion nalezy zaczac od
poczatku listy imion. Wpisow w pliku ma byc tyle ile jest nazwisk.
Wynik wyswietlic~~

6c Dodac do skryptu dwie opcje:
~~1) Zapisania wygenerowanej listy do pliku~~
2) Wyslania wygenerowanej listy na serwer (odpowiedz.php)

6d
~~Wykorzystujac przykladowy plik (hack.txt) prosze policzyc ile razy wystepuje
slowo "komputer".~~

6e
Wykorzystujac przykladowy plik (hack.txt) prosze znalezc najdluzszy "ciag
modulacyjny".

6f
~~Prosze wyswietlic dane wygenerowane w zadaniu 6b z polskimi znakami.~~
