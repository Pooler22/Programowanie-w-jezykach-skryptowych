import operator


class Sort:
    @staticmethod
    def sort(in1):
        dict1 = dict(zip(in1, [x.split("@")[1].count(".") for x in in1]))
        return [k[0] for k in list(sorted(dict1.items(), key=operator.itemgetter(1)))]

tab = ["abc.xyz@serwer.o.bardzo.dlugiej.nazwie.com", "jan.kot@gmail.com", "dsan@kis.p.lodz.pl"]
print(Sort.sort(tab))
